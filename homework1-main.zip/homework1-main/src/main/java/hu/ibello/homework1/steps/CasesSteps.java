package hu.ibello.homework1.steps;

import hu.ibello.core.Name;
import hu.ibello.homework1.pages.CasesPage;
import hu.ibello.steps.StepLibrary;
import hu.ibello.homework1.pages.CasePage;

@Name("Cases")
public class CasesSteps extends StepLibrary {

	private CasesPage cases;
	
	// TODO insert a field here with the type 'CasePage'
	private CasePage casePage;
	
	public void I_open_the_page() {
		cases.I_open_the_page();
		cases.I_see_that_the_page_is_opened();
	}
	
	public void I_see_that_the_first_person_is_$(String personName) {
		cases.I_see_that_the_first_person_is_$(personName);
	}
	
	public void I_change_the_first_persons_name_to_$(String personName) {
		cases.I_open_the_first_case();
		// TODO verify that the page was opened
		casePage.I_see_that_the_new_page_is_open_$();
		// TODO enter the name into the person field
		casePage.I_click_the_person_field();
		casePage.I_fill_the_person_field(personName);
		// TODO save the page
		casePage.I_save_the_page();
		// TODO validate that the current page is the 'cases'
		cases.I_see_that_the_first_person_is_$(personName);
	}
	
}
