package hu.ibello.homework1.pages;

import hu.ibello.core.Name;
import hu.ibello.elements.WebElement;
import hu.ibello.pages.PageObject;
import hu.ibello.search.By;
import hu.ibello.search.Find;

@Name("Case Page")
public class CasePage extends PageObject {
	
	@Find(by = By.ID, using = "person")
	private WebElement inputPersonField;

	@Find(by = By.TEXT, using = "Mentés")
	private WebElement saveButton;
	
	public void I_see_that_the_new_page_is_open_$() {
		expectations().expect(inputPersonField).toBe().displayed();
	}

	public void I_click_the_person_field() {
		doWith(inputPersonField).click();
		doWith(inputPersonField).sendKeys(keys().CONTROL(), "a");
	}
	
	public void I_fill_the_person_field(String personName) {
		doWith(inputPersonField).sendKeys(personName);
	}
	
	public void I_save_the_page() {
		doWith(saveButton).click();
	}
	

}
